<?php
//Mengambil data isi konten website di controller (dari variabel isi)
if ($isi) {
    $this->load->view($isi);
}