<?php
// LOAD SLIDER 
include('slider.php');
//load kategori/banner
// include('kategori.php');
//load dat5a produk
include('produk.php');
//load berita
// include('berita.php');