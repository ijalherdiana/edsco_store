<!-- Banner -->
<section class="banner bgwhite p-t-40 p-b-40">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 ">
             <?php foreach ($kategori as $kategori):?>  
                <!-- block1 -->
                <div class="block1 hov-img-zoom m-b-30 col-md-4">
                    <img src="<?= base_url() ?>assets/frontend/images/banner-02.jpg" alt="IMG-BENNER">

                    <div class="block1-wrapbtn w-size2">
                        <!-- Button -->
                        <a href="#" class="flex-c-m size2 m-text2 bg3 hov1 trans-0-4">
                            Dresses
                        </a>
                    </div>
                </div>
            <?php endforeach;?>
            
            </div>
            </div>
        </div>
    </div>
</section>